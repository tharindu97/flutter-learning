package com.example.screenshotd

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
